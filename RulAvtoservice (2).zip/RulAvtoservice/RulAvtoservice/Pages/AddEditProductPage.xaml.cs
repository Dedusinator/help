﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using RulAvtoservice.Entities;

namespace RulAvtoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductPage.xaml
    /// </summary>
    public partial class AddEditProductPage : Page
    {
        Product product = new Product();
        bool isEdits = false;
        public AddEditProductPage(Product currentProduct)
        {
            InitializeComponent();
            cmb_Category.ItemsSource = ProductCategory;
            cmb_Supplier.ItemsSource = ProductSupplier;
            cmb_Manufacturer.ItemsSource = ProductManufacturer;
            DataContext = currentProduct;
            if (currentProduct != null)
            {
                product = currentProduct;
                isEdits = true;
                btn_DeleteProduct.Visibility = Visibility.Visible;
                tb_Article.Text = product.ProductArticleNumber;
                cmb_Category.SelectedIndex = product.IDProductCategory - 1;
                cmb_Manufacturer.SelectedIndex = product.IDProductManufacturer - 1;
                cmb_Supplier.SelectedIndex = product.IDProductSuplier - 1;
                tb_Article.IsEnabled = false;
            }
            else
            {
                GenerateArticle();
            }
        }

        public string[] ProductCategory =
        {
            "Зарядные устройства",
            "Съемники подшипников",
            "Автозапчасти",
            "Ручные инструменты",
            "Автосервис",
            "Аксессуары"
        };

        public string[] ProductManufacturer =
     {
            "KOLNER",
            "AIRLINE",
            "BIG FIGHTER",
            "STV", 
            "JONNESWAY",
            "BOSCH",
            "TCL",
            "JTC",
            "GRASS",
            "SMART",
            "CHAMPION",
            "ALCA",
            "MOBIL",
            "EXPERT",
            "HAMMER"
        };

        public string[] ProductSupplier =
        {
            "220-volt",
            "Максидом"
        };

        public void GenerateArticle()
        {
            string article = string.Empty;
            Random rnd = new Random();
            char[] ch4r = "ABCDEFGHUJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
            for (int i = 0; i <= 6; i++)
            {
                article += ch4r[rnd.Next(ch4r.Length)];
            }
            if (RulEntities.GetContext().Product.Where(p => p.ProductArticleNumber == article).Count() > 0)
            {
                GenerateArticle();
            }
            else
            {
                tb_Article.Text = article;
            }
        }

        private void btn_EnterImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog GetImageDialog = new OpenFileDialog(); //Открываем диалоговое окно

            GetImageDialog.Filter = "Файлы изображений: (*.png, *.jpg, *.jpeg)|*.png;*.jpg;*.jpeg"; //Ставим фильтр видимости файлов
            GetImageDialog.InitialDirectory = @"G:\МДК.01.01\RulAvtoservice\RulAvtoservice\Resources\Product"; //прописываем путь к папке ресурсов проекта
            if (GetImageDialog.ShowDialog() == true)
            {
                product.ProdctPhotoPath = GetImageDialog.SafeFileName;
                img.Source = new BitmapImage(new Uri(GetImageDialog.FileName));
            }
        }

        private void btn_DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show($"Вы действительно хотите удалить {product.ProductName}?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                try
                {
                    RulEntities.GetContext().Product.Remove(product);
                    RulEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    NavigationService.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }


        private void btn_SaveProduct_Click(object sender, RoutedEventArgs e) {
            StringBuilder errors = new StringBuilder();

            if (product.ProductCost < 0)
                errors.AppendLine("Стоимость не может быть отрицательной!");
            if (product.ProductDiscountAmount > product.ProductMaxDiscount && product.ProductDiscountAmount >= 0)
                errors.AppendLine("Действующая скидка на товар не может быть больше максимальнй скидки!");
            if (product.ProductMaxDiscount > 100 || product.ProductMaxDiscount < 0)
                errors.AppendLine("Неверно заполненно поле с максимальной скидкой!");
            if (product.ProductQuantityInStock < 0)
                errors.AppendLine("Товаров в наличии не может быть менее 0");
            if (product.ProductName == null)
                errors.AppendLine("Наименование пусто!");
            if (product.Unit == null)
                errors.AppendLine("Единица измерений отсутствует!");


            
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

                product.ProductArticleNumber = tb_Article.Text;
                product.IDProductCategory++;
                product.IDProductManufacturer++;
                product.IDProductSuplier++;
                if (isEdits)
            {
                RulEntities.GetContext().Product.Remove(product);
                RulEntities.GetContext().SaveChanges();
            }
                RulEntities.GetContext().Product.Add(product);
                RulEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.GoBack();
            
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            //}
        }
    }
}


