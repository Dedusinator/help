﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RulAvtoservice.Entities;

namespace RulAvtoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autorization.xaml
    /// </summary>
    public partial class Autorization : Page
    {
        public Autorization()
        {
            InitializeComponent();
            tb_captcha.MaxLength = 5;
            string location = System.Reflection.Assembly.GetExecutingAssembly().Location;
            int ind = location.Length - 29; //
            path = location.Remove(ind);
            path += @"\Resources\Captcha\Background\";
            imageBox.Visibility = Visibility.Collapsed;
            lbl_capthca.Visibility = Visibility.Collapsed;
            btn_Synth.Visibility = Visibility.Collapsed; 
            btn_Refresh.Visibility = Visibility.Collapsed;
            tb_captcha.Visibility = Visibility.Collapsed;
            lbl_error.Visibility = Visibility.Collapsed;
        }
        public string path;

        public int countAttempts = 0;

        private void btn_Synth_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SpeechSynthesizer synth = new SpeechSynthesizer();

                synth.SetOutputToDefaultAudioDevice();

                char[] array = lbl_capthca.Content.ToString().ToCharArray();

                for (int i = 0; i < array.Length; i++)
                {
                    synth.Speak(array[i].ToString());
                }
            }
            catch
            {
            }
        }
        private void GenerateCapthca()
        {
            Random rnd = new Random();
            int number = rnd.Next(0, 6);
            imageBox.Source = BitmapFrame.Create(new Uri(path + $"{number}.jpg"));
            lbl_capthca.Foreground = (number == 0 || number == 1 || number == 3 || number == 4) ? System.Windows.Media.Brushes.Black : System.Windows.Media.Brushes.White;
            string ucode = string.Empty;
            char[] ch4r = "abcdefghijklmnopqrstuvwxyzABCDEFGHUJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
            for (int i = 0; i < 5; i++)
            {
                ucode += ch4r[rnd.Next(ch4r.Length)];
            }
            lbl_capthca.Content = ucode;
        }


        private void btn_Refresh_Click(object sender, RoutedEventArgs e)
        {
            GenerateCapthca();
        }

        private void btn_EnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null));
        }

        private async void btn_Enter_Click(object sender, RoutedEventArgs e)
        {
            string login = tb_login.Text.Trim();
            string password = tb_password.Password.Trim();

            if (countAttempts > 0)
            {
                lbl_error.Visibility = Visibility.Visible;
                lbl_error.Content = "Неверно введён логин или пароль!";
                imageBox.Visibility = Visibility.Visible;
                lbl_capthca.Visibility = Visibility.Visible;
                btn_Synth.Visibility = Visibility.Visible; 
                btn_Refresh.Visibility = Visibility.Visible;
                tb_captcha.Visibility = Visibility.Visible;
                GenerateCapthca();
            }
            if (tb_captcha.Text == lbl_capthca.Content.ToString() || lbl_capthca.Visibility == Visibility.Collapsed)
            {
                User user = new User();
                user = RulEntities.GetContext().User.Where(p => p.UserLogin == login && p.UserPassword == password).FirstOrDefault();
                int userCount = RulEntities.GetContext().User.Where(p => p.UserLogin == login && p.UserPassword == password).Count();

                if (userCount > 0)
                {
                    countAttempts = 0;
                    LoadForm(user.Role.RoleID, user);
                }
                else
                {
                    tb_login.Clear();
                    tb_password.Clear();
                    tb_captcha.Clear();
                    countAttempts++;
                    lbl_error.Content = "Неверно введён логин или пароль!";
                    GenerateCapthca();
                }
            }
            else
            {
                tb_captcha.Clear();
                countAttempts++;
                GenerateCapthca();
            }
            if (countAttempts == 3)
            {
                btn_EnterGuest.IsEnabled = false;
                btn_Enter.IsEnabled = false;
                countAttempts = 0;
                for (int i = 10; i >= 0; i--)
                {
                    lbl_error.Content = $"Стой! Подожди {i} секунд";
                    await Task.Delay(1000);
                }
                lbl_error.Content = "Продолжай!";
                btn_Enter.IsEnabled = true;
                btn_EnterGuest.IsEnabled = true;

            }
        }
        public void LoadForm(int roleId, User user)
        {
            //1 - Администратор 2 - Клиент 3 - Менеджер
            switch (roleId)
            {
                case 1:
                    NavigationService.Navigate(new Administrator(user)); break;
                case 2:
                    NavigationService.Navigate(new Client(user)); break;
                case 3:
                    NavigationService.Navigate(new Client(user)); break;
            }
        }
    }
}
